

#numeric type
x = 20
print(x)
print(type(x))

x = 20.5
print(x)
print(type(x))

x = 20j
print(x)
print(type(x))

#text type

x = "hello python world"
print(x)
print(x[1])
print(len(x))
print("hello" in x)
print("raja" in x)

x = "hello python world"
if "hello" in x:
  print("yes, 'hello' is present")
x = "hello python world"
if not "raja" in x:
      print("no, 'raja' is not present")
      
      x = "hello python world"
      if "python" in x:
        print("yes, 'python' is present")
  
  #lists
  
a = ["apple", "bannana", "orange", "mango"]
print(a)
print(len(a))
print(type(a))





list1 = ["apple", "bannana", "orange"]
list2 = [1, 9, 3, 4, 5]
list3 = [True, False, False]

print(list1)
print(list2)
print(list3)

list1 = ["apple", "banana", "orange"]
list2 = [1, 5, 7, 9, 3]
list3 = [True, False, False]

print(list1)
print(list2)
print(list3)

x = ["apple", "bannana", "orange"]
print(type(x))

# tupple

x = ("raja", "rocky", "ravi")
print(x)
print(type(x))
print(len(x))

x = ("raja" "rocky" "ravi")
print(type(x))
 
 # sets
 
x = {"raja", "rocky", "ravi"}
print(x)
print(type(x))
print(len(x))

x = {"raja", "rocky", "ravi"}
y = {1, 2, 3, 4}
z = {True,False, False}

print(x)
print(y)
print(z)

r = {"abc", 34, True, 40, "male"}

print(r)

x = {"raja", "rocky", "ravi"}
for y in x:
  print(y)
  print("raja" in x)
  print("lalith" in x)
  
x = {"raja", "rocky", "ravi"}
x.add("lalith")
print(x)

x = {"raja", "rocky", "ravi"}
y = {"mango", "orange", "gauva"}
x.update(y)
print(x)

x = {"raja", "rocky", "ravi"}
x.remove("rocky")
print(x)

x = {"raja", "rocky", "ravi"}
x.discard("rocky")
print(x)

x = {"raja", "rocky", "ravi"}
x.clear()
print(x)

x = {"raja", "rocky", "ravi"}
del x
#print(x)

x = {"a", "b", "c"}
y = {1, 2, 3}

z = x.union(y)
print(z)

#dict

thisdict =	{
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}
print(thisdict)

thisdict =	{
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}
print(thisdict(["brand"]))

thisdict = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}
print(thisdict["brand"])