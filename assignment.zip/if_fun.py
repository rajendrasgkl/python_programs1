'''
a = 350
b = 450

if b > a:
    print("b is greater than a")
elif a < b:
    print("a is less thna b")
    
    
a = 200
b = 33
if b > a:
  print("b is greater than a")
elif a == b:
  print("a and b are equal")
else:
  print("a is greater than b")
  

 a = 50
 b = 30
if a > b: print("a is greater than b")
 
 
 
 a = 100
 b = 50
 if a > b: print("a is greater than b")
 '''
a = 500
b = 800

if a < b: 
    print("b is greater than a")
elif a == b:
    print("a is  equal to b") 
else:
    print("a is less than b")
    


a = 800
b = 300
c = 900

if a > b and c > a:
    print("Both conditions are True")
    
a = 100
b = 25
c = 350
if a > b or c < a:
    print("Atleast one condition True")
    

x = 50

if x > 10:
    print("above ten,")
if x > 20:
    print("and also above 20!")
else:
    print("but not above 20.")
    
   
a = 50
b = 80

if b > a:
    pass

fruits = ["mango", "apple", "grape"]
for x in fruits:
    print(x)

fruits = ["mango", "apple", "grape"]
for x in "apple":
    print(x)
    

fruits = ["mango", "apple", "grape"]
for x in fruits:
  if x == "apple":
    break
print(x)

fruits = ["mango", "apple", "grape"]
for x in fruits:
  if x == "apple":
    continue
print(x)

for x in range(2,6):
    print(x)
    
for x in range(2,30,10):
    print(x)
    
for x in range(6):
    print(x)
else:
    print("finally finished!")
    

raja = ("rocky", "lalith", "adarsh")
manu = ("vamshi", "prithivi", "john")

for x in raja:
  for y in manu:
    print(x,y)
    
import datetime

x = datetime.datetime.now()
print(x)

import datetime

x = datetime.datetime.now()

print(x.year)
print(x.strftime("%A"))

import datetime

x = datetime.datetime(1995, 11, 9)
print(x.strftime("%b"))

import datetime

x = datetime.datetime(1995, 11, 9)

print(x.strftime("%B"))
