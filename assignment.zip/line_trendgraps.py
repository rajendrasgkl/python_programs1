import matplotlib.pyplot as plt
import numpy as np
y = np.array([1, 8, 9, 5,])
plt.plot(y)
plt.show()
