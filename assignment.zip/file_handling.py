file = open("new.txt","r+")
print(file.read())

import datetime
x = datetime.datetime.now()
print(x)

#withopen method
with open("new.txt","r") as raja:
    print(raja.read())
file.close

file = open("new.txt","a")
file.write("raja is good boy")
file.close()
file = open("new_txt","r")
print(file.read()) 


x = open("new.txt", "w")
x.write("Woops! I have deleted the content!")
x.close()

f = open("new.txt", "r")
print(f.read())

#about "os"

import os
os.rmdir("raja123.py")

import os
os.path.exist("new.txt")
 