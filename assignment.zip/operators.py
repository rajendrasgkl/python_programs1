#arthimetic opertors

a = 5	
b = 3
print(a+b)
print(a-b)
print(a*b)
print(a/b)
print(a%b)
print(a//b)
print(a**b)

#assignment operators

a = 5
b = 3
print(a==b)

a = 5
a += 3
print(a)

a = 5
a -= 3
print(a)

a = 5
a *= 3
print(a)

a = 5
a /= 3
print(a)

a = 5
a %= 3
print(a)

a = 5
a //= 3
print(a)

a = 5
a **= 3
print(a)

a = 5
a &= 3
print(a)

a = 5
a |= 3
print(a)

a = 5
a ^= 3
print(a)

a = 5
a >>= 3
print(a)
a = 5
a <<= 3
print(a)

#comparsion operators

a = 10
b = 20

print(a==b)
print(a!=b)
print(a<b)
print(a>b)
print(a>=b)
print(a<=b)

# logical operators
#and
x = 8
print(x > 3 and x < 10)
#or
x = 8
print(x > 3 or x < 10)
#not
x = 8
print(not(x > 3 and x < 10))

#identity operators

x = 5 
y = 3

print(x is y)
print(x is not y)

#memebership operators

x = ["apple", "banana"]

print("banana" in x)
print("pineapple" not in x)


