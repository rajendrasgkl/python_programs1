def my_function():
   print("good morning to the python world")

my_function()

def my_function(x):
    print(x + "adarsh")

my_function("email")
my_function("gmail")
my_function("html")
   
 '''   
def my_function(fname, lname):
    print(fname + " " + lname)

my_function("Emil", "Refsnes")

def my_function(fname, lname):
    print(fname + "" + lname)
my_function("emil")

'''


def my_function(*childs):
    print("youngest kid is " + "childs[2]")
    
#my_function("raja", "adarsh", "rocky")

a = 250
b = 350

print(a>b)